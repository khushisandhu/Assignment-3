insert into books (title, author)
values ('The 7 Habits of Highly Effective People', 'Stephen R. Covey');

insert into books (title, author)
values ('The Martian', 'Andy Weir');

insert into reviews (text, book_id)
values ('An older book, but still a very good read for principle-centered leadership.', 1);

insert into reviews (text, book_id)
values ('A great science fiction book about an astronaut stranded on Mars', 2);
