package com.example.bookreview.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

    private boolean loggedIn = false; // Flag to track login status

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) {
        // Implement logic to check if the username and password are correct
        // For example, you can check against your UserRepository

        if (username.equals("correctUsername") && password.equals("correctPassword")) {
            loggedIn = true;
            return "redirect:/index";
        } else {
            return "redirect:/login";
        }
    }

    @GetMapping("/index")
    public String index(Model model) {
        // Pass the login status to the template
        model.addAttribute("loggedIn", loggedIn);
        return "index";
    }

    // Other controller methods...
}
