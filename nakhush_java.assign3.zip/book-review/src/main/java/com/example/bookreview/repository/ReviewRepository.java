package com.example.bookreview.repository;

import com.example.bookreview.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    // Custom query methods if needed
}
