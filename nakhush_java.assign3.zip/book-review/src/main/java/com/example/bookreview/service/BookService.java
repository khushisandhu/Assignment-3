package com.example.bookreview.service;

import com.example.bookreview.model.Book;

import java.util.List;

public interface BookService {
    List<Book> getAllBooks();
    void saveBook(Book book);

        // Other existing methods...
        Book getBookById(Long id);

    void saveReviewForBook(Long bookId, String reviewText);
}
