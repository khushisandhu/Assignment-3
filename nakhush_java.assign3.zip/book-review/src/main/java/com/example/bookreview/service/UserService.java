package com.example.bookreview.service;

import com.example.bookreview.model.User;
import com.example.bookreview.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public boolean registerUser(String username, String password) {
        // Check if the username is available
        if (userRepository.findByUsername(username) != null) {
            return false; // Username exists
        }

        // Create a new user and save it
        User newUser = new User();
        newUser.setUsername(username);
        newUser.setPassword(password);

        userRepository.save(newUser);
        return true;
    }
}
