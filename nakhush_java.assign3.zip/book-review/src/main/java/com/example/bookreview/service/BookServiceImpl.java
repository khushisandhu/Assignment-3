package com.example.bookreview.service;

import com.example.bookreview.model.Book;
import com.example.bookreview.model.Review;
import com.example.bookreview.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class BookServiceImpl implements BookService {
    @Autowired
    private BookRepository bookRepository;

    @Override
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public void saveBook(Book book) {
        bookRepository.save(book); // This line saves the book to the database
    }

    @Override
    public Book getBookById(Long id) {
        return bookRepository.findById(id).orElse(null);
    }

    @Override
    public void saveReviewForBook(Long bookId, String reviewText) {
        Book book = bookRepository.findById(bookId).orElse(null);
        if (book != null) {
            Review review = new Review();
            review.setBook(book);
            review.setText(reviewText);
            // Set other review details if needed

            // Add the review to the book's list of reviews
            book.getReviews().add(review);
            bookRepository.save(book); // Save the updated book with the new review
        }

    }
}