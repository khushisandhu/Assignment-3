package com.example.bookreview.controller;

import com.example.bookreview.model.Book;
import com.example.bookreview.model.Review;
import com.example.bookreview.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class BookController {

    //    display books list
    @Autowired
    private BookService bookService;

    @GetMapping("/")
    public String viewHomePage(Model model) {
        model.addAttribute("listBooks", bookService.getAllBooks());
        return  "index";
    }
    @GetMapping("/login")
    public String login(){
        return "login";
    }
@GetMapping("/showNewBookForm")
    public String showNewBookForm(Model model){
        Book book= new Book();
        model.addAttribute("book", book);

        return "addBook";    }

    @PostMapping("/addBook")
    public  String addBook(@ModelAttribute("book") Book book){
        bookService.saveBook(book);
        return "redirect:/";
    }

    @GetMapping("/addReviews/{bookId}")
    public String showReviewsForBook(@PathVariable("bookId") Long bookId, Model model) {
        Book book = bookService.getBookById(bookId); // Implement this method in BookService
        model.addAttribute("existingReviews", book.getReviews());
        return "addReviews"; // This should be the name of your HTML file for displaying reviews
    }
//new review
    @PostMapping("/addReviews/{bookId}")
    public String submitReview(@PathVariable("bookId") Long bookId, @RequestParam("reviewText") String reviewText) {
        bookService.saveReviewForBook(bookId, reviewText);
        return "redirect:/addReviews/{bookId}"; // Redirect to the index page or wherever appropriate
    }

}